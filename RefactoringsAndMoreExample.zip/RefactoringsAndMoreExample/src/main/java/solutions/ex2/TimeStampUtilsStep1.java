package solutions.ex2;

import java.time.LocalDateTime;

import exercises.ex2.external.ComplexFrequency;
import exercises.ex2.external.ExtTimePeriod;

/**
 * Beispiel fèr eine Kombination von Basis-Refactorings, Schritt 1
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class TimeStampUtilsStep1 
{
	public static String createTimeStampString(final ExtTimePeriod currentPeriod, 
	                                            final ComplexFrequency frequency) 
	{
		final LocalDateTime start = currentPeriod.getDateTime();
		
		final boolean isMonthly = frequency == ComplexFrequency.P1M;
		final int divisor = isMonthly ? 1 : 3;
		final String addition = isMonthly ? "" : "Q";
		final int value = ((start.getMonthValue() - 1) / divisor + 1);
	
		return start.getYear() + "-" + addition + value;
	}
}

