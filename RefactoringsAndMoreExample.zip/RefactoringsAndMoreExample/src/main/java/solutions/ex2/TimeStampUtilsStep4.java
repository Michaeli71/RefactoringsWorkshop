package solutions.ex2;

import java.time.LocalDateTime;

import exercises.ex2.external.ExtTimePeriod;

/**
 * Beispiel f�r eine Kombination von Basis-Refactorings, Schritt 4
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014, 2020 by Michael Inden 
 */
public class TimeStampUtilsStep4 
{
	public static String createTimeStampString(final ExtTimePeriod currentPeriod, 
					                           final boolean isMonthly) 
	{
		final LocalDateTime start = currentPeriod.getDateTime();
	
		return createTimeStampString(isMonthly, start);
	}
	
	public static String createTimeStampString(final boolean isMonthly, 
					                           final LocalDateTime start) 
	{
		final int divisor = isMonthly ? 1 : 3;
		final String addition = isMonthly ? "" : "Q";
		final int value = ((start.getMonthValue() - 1) / divisor + 1);
	
		return start.getYear() + "-" + addition + value;
	}
}

