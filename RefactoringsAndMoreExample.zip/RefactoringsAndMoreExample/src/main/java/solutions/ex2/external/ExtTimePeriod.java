package solutions.ex2.external;

import java.time.LocalDateTime;

/**
 * Beispielklasse zur Modellierung einer Zeitperiode
 *  
 * @author Michael Inden
 * 
 * Copyright 2014 by Michael Inden 
 */
public class ExtTimePeriod 
{
	public LocalDateTime getDateTime() 
	{
		return LocalDateTime.now();
	}
}
