package solutions.ex2;

import java.time.LocalDateTime;

/**
 * Beispiel f�r eine Kombination von Basis-Refactorings, Schritt 7
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class TimeStampUtilsStep7 
{
	public static String createTimeStampString(final LocalDateTime start, 
					                           final boolean isMonthly) 
	{
		final int divisor = isMonthly ? 1 : 3;
		final String addition = isMonthly ? "" : "Q";
		
		// Inline
		return start.getYear() + "-" + addition + ((start.getMonthValue() - 1) / divisor + 1);
	}
}

