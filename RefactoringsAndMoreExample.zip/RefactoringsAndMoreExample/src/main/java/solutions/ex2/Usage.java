package solutions.ex2;

import exercises.ex2.external.ComplexFrequency;
import exercises.ex2.external.ExtTimePeriod;

public class Usage {

	public static void main(String[] args) {

		final ExtTimePeriod currentPeriod = new ExtTimePeriod();
		final ComplexFrequency frequency = ComplexFrequency.P6M;
		
		final String timeStamp = TimeStampUtilsStep2.createTimeStampString(currentPeriod, frequency);
	}

	private static void orig() {
		final ExtTimePeriod currentPeriod = new ExtTimePeriod();
		final ComplexFrequency frequency = ComplexFrequency.P6M;
		
		final String timeStamp = TimeStampUtils.createTimeStampString(currentPeriod, frequency);
	}
}
