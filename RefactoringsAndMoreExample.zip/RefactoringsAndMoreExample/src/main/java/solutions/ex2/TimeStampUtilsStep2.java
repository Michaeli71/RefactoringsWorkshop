package solutions.ex2;

import java.time.LocalDateTime;

import exercises.ex2.external.ComplexFrequency;
import exercises.ex2.external.ExtTimePeriod;

/**
 * Beispiel für eine Kombination von Basis-Refactorings, Schritt 2
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014, 2020 by Michael Inden 
 */
public class TimeStampUtilsStep2 
{
	public static String createTimeStampString(final ExtTimePeriod currentPeriod, 
	                                           final ComplexFrequency frequency) 
	{
		final boolean isMonthly = frequency == ComplexFrequency.P1M;		
		return createTimeStampString(currentPeriod, isMonthly);
	}

	public static String createTimeStampString(final ExtTimePeriod currentPeriod, final boolean isMonthly) 
	{
		final LocalDateTime start = currentPeriod.getDateTime();
	
		final int divisor = isMonthly ? 1 : 3;
		final String addition = isMonthly ? "" : "Q";
		final int value = ((start.getMonthValue() - 1) / divisor + 1);
	
		return start.getYear() + "-" + addition + value;
	}
}

