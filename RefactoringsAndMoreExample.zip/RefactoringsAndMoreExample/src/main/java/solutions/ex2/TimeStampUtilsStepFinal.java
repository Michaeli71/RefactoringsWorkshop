package solutions.ex2;

import java.time.LocalDateTime;

/**
 * Beispiel f�r eine Kombination von Basis-Refactorings, finaler Schritt
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class TimeStampUtilsStepFinal 
{
	public static String createTimeStampString(final LocalDateTime start, 
					                           final boolean isMonthly) 
	{
		if (isMonthly) 
		{
			return start.getYear() + "-" + start.getMonthValue();
		}
		return start.getYear() + "-Q" + (1 + (start.getMonthValue() - 1) / 3);
	}
}
