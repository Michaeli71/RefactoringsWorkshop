package solutions.ex2;

import java.time.LocalDateTime;

/**
 * Beispiel f�r eine Kombination von Basis-Refactorings, Schritt 8
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class TimeStampUtilsStep8 
{
	public static String createTimeStampString(final LocalDateTime start, 
					                           final boolean isMonthly) 
	{
		final int divisor;
		final String addition;
		if (isMonthly) {
			divisor = 1;
			addition = "";
		} else {
			divisor = 3;
			addition = "Q";
		}
	
		return start.getYear() + "-" + addition + ((start.getMonthValue() - 1) / divisor + 1);
	}
}
