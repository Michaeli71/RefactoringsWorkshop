package solutions.ex2;

import java.time.LocalDateTime;

public enum SupportedFrequencies 
{
   MONTHLY
   {
      public String createTimeStampString(final LocalDateTime start)
      {
         return start.getYear() + "-" + start.getMonthValue();
      }
   }, 

   QUARTERLY
   {
      public String createTimeStampString(final LocalDateTime start)
      {
         return start.getYear() + "-Q" + (1 + (start.getMonthValue() - 1) / 3);   
      }
   };

   public abstract String createTimeStampString(final LocalDateTime start);
}