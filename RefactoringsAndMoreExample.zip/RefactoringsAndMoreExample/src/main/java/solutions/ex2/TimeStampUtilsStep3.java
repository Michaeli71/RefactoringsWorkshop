package solutions.ex2;

import java.time.LocalDateTime;

import exercises.ex2.external.ExtTimePeriod;

/**
 * Beispiel f�r eine Kombination von Basis-Refactorings, Schritt 3
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014, 2020 by Michael Inden 
 */
public class TimeStampUtilsStep3 
{
	public static String createTimeStampString(final ExtTimePeriod currentPeriod, final boolean isMonthly) 
	{
		final LocalDateTime start = currentPeriod.getDateTime();
	
		final int divisor = isMonthly ? 1 : 3;
		final String addition = isMonthly ? "" : "Q";
		final int value = ((start.getMonthValue() - 1) / divisor + 1);
	
		return start.getYear() + "-" + addition + value;
	}
}

