package solutions.ex2;

import java.time.LocalDateTime;

/**
 * Beispiel f�r eine Kombination von Basis-Refactorings, kurz vor dem finalen Schritt
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014, 2020 by Michael Inden 
 */
public class TimeStampUtilsStepPreFinal 
{
	public static String createTimeStampString(final LocalDateTime start, 
					                           final boolean isMonthly) 
	{
		if (isMonthly) 
		{
			return start.getYear() + "-" + ((start.getMonthValue() - 1) / 1 + 1);
		}
		return start.getYear() + "-Q" + ((start.getMonthValue() - 1) / 3 + 1);
	}
}
