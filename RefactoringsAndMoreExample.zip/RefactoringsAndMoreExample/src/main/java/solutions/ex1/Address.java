package solutions.ex1;

public class Address 
{
	private final String city;
	private final String country;
	
	Address(final String city, final String country)
	{
		this.city = city;
		this.country = country;
	}

	String getCountry() {
		return country;
	}

	String getCity() {
		return city;
	}

	public void printAddress()
	{
		System.out.println("City: " + getCity());
		System.out.println("Country: " + getCountry());
	}

	@Override
	public String toString() {
		return "Address [city=" + city + ", country=" + country + "]";
	}
}
