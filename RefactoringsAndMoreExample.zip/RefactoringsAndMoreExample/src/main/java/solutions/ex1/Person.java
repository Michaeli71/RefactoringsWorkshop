package solutions.ex1;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class Person 
{
	private final String name;
	private int age;
	
	private final List<Address> addresses = new ArrayList<>();
	
	public Person(String name, int age) 
	{
		this.name = name;
		this.age = age;
	}

	public void registerAddress(Address address) 
	{	
		addresses.add(address);
	}	
	
	public void printAddresses()
	{
		addresses.forEach(address -> address.printAddress());
	}

	String getName() 
	{
		return name;
	}

	int getAge() 
	{
		return age;
	}

	long getAgeCorrected()
	{
		final LocalDate birthday = LocalDate.of(1984, 11, 27);
		return ChronoUnit.YEARS.between(birthday, LocalDate.now());
	}
	
	void setAge(int age) 
	{
		this.age = age;
	}
	
	
	@Override
	public String toString() 
	{
		return "Person [name=" + getName() + ", age=" + getAge() + ", addresses=" + addresses + "]";
	}
}
