package exercises.ex1;

public class AddressPrinterApp
{
	public static void main(final String[] args) 
	{		
		final Person karthi = new Person();
		karthi.personInit("Karthi", 33);

		final Person mike = new Person();
		mike.personInit("Mike", 46);
		mike.setFirstAddress(new Address("Zürich", "Switzerland"));
		mike.setFirstAddress(new Address("Aachen", "Germany"));
		
		System.out.println(karthi);
		System.out.println(mike);
		
		System.out.println("\nMIke's addresses:");
		mike.printAddresses();
	}
}
