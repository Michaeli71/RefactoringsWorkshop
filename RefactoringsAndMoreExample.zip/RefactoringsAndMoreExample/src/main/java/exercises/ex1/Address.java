package exercises.ex1;

public class Address
{
	public final String city;
	String country;

	String street;

	Address(String city, String country)
	{
		this.city = city;
		this.country = country;
	}
}
