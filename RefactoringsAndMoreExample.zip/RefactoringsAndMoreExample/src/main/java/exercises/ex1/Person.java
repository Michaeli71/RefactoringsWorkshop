package exercises.ex1;

import java.util.ArrayList;
import java.util.List;

public class Person 
{
	String name;
	int age;
	
	List<Address> addresses = new ArrayList<>();
	
	public Person()
	{		
	}
	
	public void personInit(String name, int age)
	{		
		name = name;
		age = age;
	}

	
	public void setFirstAddress(Address address) 
	{	
		addresses.add(address);
	}	
	
	public void printAddresses()
	{
		for (Address address : addresses)
		{
			System.out.println("City: " + address.city);
			System.out.println("Country: " + address.country);
		}
	}

	@Override
	public String toString() 
	{
		return "Person [name=" + name + ", age=" + age + ", addresses=" + addresses + "]";
	}
}
