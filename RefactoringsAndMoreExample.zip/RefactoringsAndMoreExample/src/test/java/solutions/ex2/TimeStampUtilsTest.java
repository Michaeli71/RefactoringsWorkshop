package solutions.ex2;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import solutions.ex2.TimeStampUtilsStepFinal;

/**
 * Beispiel f�r einfache Testf�lle
 *  
 * @author Michael Inden
 * 
 * Copyright 2014, 2020  by Michael Inden 
 */
public class TimeStampUtilsTest 
{
	@Test
	public void test_createTimeStampString_Monthly()
	{
		final boolean MONTHLY = true;
		assertEquals("2000-2",  TimeStampUtilsStepFinal.createTimeStampString(LocalDateTime.of(2000, 2, 7, 0, 0), MONTHLY));
		assertEquals("2000-7", TimeStampUtilsStepFinal.createTimeStampString(LocalDateTime.of(2000, 7, 14, 0, 0), MONTHLY));
		assertEquals("2000-12", TimeStampUtilsStepFinal.createTimeStampString(LocalDateTime.of(2000, 12, 24, 0, 0), MONTHLY));
	}
	
	@Test
	public void test_createTimeStampString_Quarterly()
	{
		final boolean QUARTERLY = false;
		assertEquals("2000-Q1", TimeStampUtilsStepFinal.createTimeStampString(LocalDateTime.of(2000, 2, 7, 0, 0), QUARTERLY));
		assertEquals("2000-Q3", TimeStampUtilsStepFinal.createTimeStampString(LocalDateTime.of(2000, 7, 14, 0, 0), QUARTERLY));
		assertEquals("2000-Q4", TimeStampUtilsStepFinal.createTimeStampString(LocalDateTime.of(2000, 12, 24, 0, 0), QUARTERLY));
	}
}
