package solutions.ex2;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import solutions.ex2.SupportedFrequencies;

/**
 * Beispiel f�r einfache Testf�lle
 * 
 * @author Michael Inden
 * 
 * Copyright 2014, 2020 by Michael Inden
 */
public class SupportedFrequenicsTest {
	@Test
	public void test_createTimeStampString_Monthly() {
		assertEquals("2000-2", SupportedFrequencies.MONTHLY.createTimeStampString(LocalDateTime.of(2000, 2, 7, 0, 0)));
		assertEquals("2000-7",  SupportedFrequencies.MONTHLY.createTimeStampString(LocalDateTime.of(2000, 7, 14, 0, 0)));
		assertEquals("2000-12", SupportedFrequencies.MONTHLY.createTimeStampString(LocalDateTime.of(2000, 12, 24, 0, 0)));
	}

	@Test
	public void test_createTimeStampString_Quarterly()
	{
		assertEquals("2000-Q1", SupportedFrequencies.QUARTERLY.createTimeStampString(LocalDateTime.of(2000, 2, 7, 0, 0)));
		assertEquals("2000-Q3", SupportedFrequencies.QUARTERLY.createTimeStampString(LocalDateTime.of(2000, 7, 14, 0, 0)));
		assertEquals("2000-Q4", SupportedFrequencies.QUARTERLY.createTimeStampString(LocalDateTime.of(2000, 12, 24, 0, 0)));
	}
}
