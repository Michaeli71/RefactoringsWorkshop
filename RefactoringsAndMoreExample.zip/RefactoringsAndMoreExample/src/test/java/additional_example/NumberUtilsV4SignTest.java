package additional_example;


import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

/**
 * Beispiel eines einfachen Unit Tests f�r die vierte Version der Klasse NumberUtils  
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class NumberUtilsV4SignTest 
{
	@Test
    public void testValidNumberInput()
    {
        assertTrue(NumberUtilsV4CombinedConditions.isNumber("12345"));
    }

	@Test
    public void testInvalidInput()
    {
        assertFalse(NumberUtilsV4CombinedConditions.isNumber("ABC"));
    }

	// Pr�fe L�nge 0 und 1 bez�glich IndexOutOfBoundsException
	@Test
    public void testNumberInputLength0()
    {
        assertFalse(NumberUtilsV4CombinedConditions.isNumber(""));
    }

	@Test
    public void testNumberInputLength1()
    {
        assertTrue(NumberUtilsV4CombinedConditions.isNumber("1"));
    }

	@Test
    public void testNullInput()
    {
		NullPointerException npe = assertThrows(NullPointerException.class, 
				                                () -> NumberUtilsV4CombinedConditions.isNumber(null));

        // Teste auf Text, ohne => Standardexception 
        assertFalse(StringUtils.isEmpty(npe.getMessage()));
    }
    
// Teste positive und negative Zahlen 
@Test
public void testNumberPositive() 
{
	assertTrue(NumberUtilsV4CombinedConditions.isNumber("+4711"), "plus sign should be accepted");
}

@Test
public void testNumberNegative() 
{
	assertTrue(NumberUtilsV4CombinedConditions.isNumber("-4711"), "minus sign should be accepted");
}
}