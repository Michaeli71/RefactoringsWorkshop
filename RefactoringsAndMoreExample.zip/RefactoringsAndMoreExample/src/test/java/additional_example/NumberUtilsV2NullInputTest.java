package additional_example;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

/**
 * Beispiel eines einfachen Unit Tests f�r die zweite Version der Klasse NumberUtils 
 * 
 * @author Michael Inden
 * 
 * Copyright 2011. 2014, 2020 by Michael Inden 
 */
public class NumberUtilsV2NullInputTest
{
    // Teste g�ltige und ung�ltige Eingaben
	@Test 
	public void testValidNumberInput()
    {
        assertTrue(NumberUtilsV2EmptyInputCorrected.isNumber("12345"));
    }

	@Test 
	public void testInvalidInput()
    {
        assertFalse(NumberUtilsV2EmptyInputCorrected.isNumber("ABC"));
    }

	// Pr�fe L�nge 0 und 1 bez�glich IndexOutOfBoundsException
	@Test 
	public void testNumberInputLength0()
    {
        assertFalse(NumberUtilsV2EmptyInputCorrected.isNumber(""));
    }

	@Test 
	public void testNumberInputLength1()
    {
        assertTrue(NumberUtilsV2EmptyInputCorrected.isNumber("1"));
    }
	
	@Test
    public void testNullInput()
    {
		NullPointerException npe = assertThrows(NullPointerException.class, 
				                                () -> NumberUtilsV2EmptyInputCorrected.isNumber(null));

        // Teste auf Text, ohne => Standardexception 
        assertFalse(StringUtils.isEmpty(npe.getMessage()));
    }
}