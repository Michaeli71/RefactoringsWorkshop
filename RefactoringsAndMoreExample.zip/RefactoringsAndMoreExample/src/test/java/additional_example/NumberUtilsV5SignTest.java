package additional_example;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;


/**
 * Beispiel eines einfachen Unit Tests f�r die f�nfte Version der Klasse NumberUtils  
 * 
 * @author Michael Inden
 * 
 * Copyright 2011, 2014 by Michael Inden 
 */
public class NumberUtilsV5SignTest 
{
	@Test
    public void testValidNumberInput()
    {
        assertTrue(NumberUtilsV5Sign.isNumber("12345"));
    }

	@Test
    public void testInvalidInput()
    {
        assertFalse(NumberUtilsV5Sign.isNumber("ABC"));
    }

	// Pr�fe L�nge 0 und 1 bez�glich IndexOutOfBoundsException
	@Test
    public void testNumberInputLength0()
    {
        assertFalse(NumberUtilsV5Sign.isNumber(""));
    }

	@Test
    public void testNumberInputLength1()
    {
        assertTrue(NumberUtilsV5Sign.isNumber("1"));
    }

	@Test
    public void testNullInput()
    {
		NullPointerException npe = assertThrows(NullPointerException.class, 
				                                () -> NumberUtilsV5Sign.isNumber(null));

        // Teste auf Text, ohne => Standardexception 
        assertFalse(StringUtils.isEmpty(npe.getMessage()));
    }
    
// Teste positive und negative Zahlen 
@Test
public void testNumberPositive() 
{
	assertTrue(NumberUtilsV5Sign.isNumber("+4711"), "plus sign should be accepted");
}

@Test
public void testNumberNegative() 
{
	assertTrue(NumberUtilsV5Sign.isNumber("-4711"), "minus sign should be accepted");
}
}